The main script to run is the main.py file. Please read the top comments of that file before running the code. Note that Python3 and the following packages are required:
Pandas, NumPy, Seaborn, matplotlib, multiprocessing, joblib, tqdm.

A PC with the following specs was used for the simulations whose results/figures/tables are presented in the paper:
CPU: Intel Core i7-7700 @ 3.60 GHz
RAM: 32 GB 
OS: Ubuntu 18.10